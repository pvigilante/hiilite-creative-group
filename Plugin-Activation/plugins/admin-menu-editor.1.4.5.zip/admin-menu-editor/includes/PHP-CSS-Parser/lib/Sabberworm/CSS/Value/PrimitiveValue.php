<?php

namespace Sabberworm\CSS\Value;

abstract class PrimitiveValue extends Value {
	
}